# KITTI Dataset

KITTI ROS Bags存放路径

---

## 获取数据

初次使用时, 请点击下述链接, 将课程配套数据下载至**当前路径**， 即: 

* 相对于Repo根目录的workspace/data/kitti

这样, 数据便可在Docker环境的/workspace/data下直接访问

[腾讯云下载地址](https://share.weiyun.com/GxqcTaE2)
